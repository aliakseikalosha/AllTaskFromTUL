﻿namespace stin_cv1
{
    public interface IWriter
    {
        void Write(string data);
        void WriteLine(string data);
        void Write(float data);
        void WriteLine(float data);
    }
}
