function g = sigmoid_scalar(z)
%SIGMOID Pocita sigmoid funkci pro z, z je skalar

% Je treba vratit promennou g

% ========================== V�� K�D ZDE ======================
g=1/(1+exp(-z));
% =============================================================

end
