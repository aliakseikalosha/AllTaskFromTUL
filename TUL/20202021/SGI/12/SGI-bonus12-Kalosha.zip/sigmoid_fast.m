function g = sigmoid_fast(z)
%SIGMOID Pocita sigmoid funkci pro z, z muze byt matice i skalar

% Je treba vratit promennou g

% ========================== V�� K�D ZDE ======================
% Pouze jeden ��dek bez cykl� !!!:
g = 1./(1+exp(-z));
% =============================================================

end
