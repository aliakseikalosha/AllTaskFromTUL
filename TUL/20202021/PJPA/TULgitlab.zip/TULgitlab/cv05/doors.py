# -*- coding: utf-8 -*-

"""
Úkol 5.
Napište program, který načte soubor large.txt a pro každé dveře vyhodnotí,
zda je možné je otevřít nebo ne. Tedy vyhodnotí, zda lze danou množinu uspořádat
požadovaným způsobem. Výstup z programu uložte do souboru vysledky.txt ve
formátu 1 výsledek =  1 řádek. Na řádek napište vždy počet slov v množině a True
nebo False, podle toho, zda řešení existuje nebo neexistuje.

Podrobnější zadání včetně příkladu je jako obvykle na elearning.tul.cz
"""

def is_solvable_count(words):
    """
    Function return true if it is possible to generate word chain out of the words
    """
    start = {}
    end = {}
    for word in words:
        word_start = word[0]
        word_end = word[-1]
        if word_start not in start:
            start[word_start] = 0
        if word_end not in end:
            end[word_end] = 0
        start[word_start] += 1
        end[word_end] += 1

    count = 0
    if any(t in end for t in start):
        for key in start:
            if key not in end:
                count += start[key]
                continue
            count += abs(start[key] - end[key])
        return count in [0, 1, 2]
    return False


def showcase(is_sol):
    """
    Showcase method for a is_solvable function
    """
    data_path = "large.txt"
    result_path = "vysledky.txt"
    result = []
    with open(data_path, "r") as file:
        task_count = int(file.readline())
        # print("Will have ", task_count, " tasks.")
        for _ in range(task_count):
            word_count = int(file.readline())
            # print("\tWill have ", word_count, " words in task.")
            words = [""] * word_count
            for j in range(word_count):
                words[j] = file.readline().strip()
                # print("\t\t", words[j])
            result.append(str(word_count) + " " + str(is_sol(words)) + "\n")
    with open(result_path, "w") as file:
        file.writelines(result)
        file.flush()


if __name__ == '__main__':
    showcase(is_solvable_count)
    exit()
