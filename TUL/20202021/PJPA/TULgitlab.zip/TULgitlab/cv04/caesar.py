"""
Vytvorte funkce encrypt a decrypt pro Caesarovu sifru.
Kompletni zadani v elearningu.
"""


def encrypt(word, offset):
    """
    :param word - slovo k zasifrovani
    :param offset - znakovy posun
    :return: zasifrovane slovo
    """
    result = ""
    for symbol in word:
        symbol = ord(symbol)
        if 64 < symbol < 91:
            _, mod = divmod((symbol - 65 + offset), 26)
            symbol = 65 + mod
        elif 96 < symbol < 123:
            _, mod = divmod((symbol - 97 + offset), 26)
            symbol = 97 + mod

        result += chr(symbol)
    return result


def decrypt(word, offset):
    """
    :param word - zasifrovane slovo
    :param offset - znakovy posun
    :return: desifrovane slovo
    """
    return encrypt(word, 26-offset)


def test_encrypt():
    text = "ahoj blazne cos cekal?"
    encoded_text = "nubw oynmar pbf prxny?"
    print(text)
    print(encoded_text)
    print(encrypt(text,13))
    print(decrypt(encoded_text,13))


if __name__ == "__main__":
    test_encrypt()
