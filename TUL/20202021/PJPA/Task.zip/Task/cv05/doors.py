# -*- coding: utf-8 -*-

""" 
Úkol 5. 
Napište program, který načte soubor large.txt a pro každé dveře vyhodnotí,
zda je možné je otevřít nebo ne. Tedy vyhodnotí, zda lze danou množinu uspořádat
požadovaným způsobem. Výstup z programu uložte do souboru vysledky.txt ve
formátu 1 výsledek =  1 řádek. Na řádek napište vždy počet slov v množině a True
nebo False, podle toho, zda řešení existuje nebo neexistuje. 

Podrobnější zadání včetně příkladu je jako obvykle na elearning.tul.cz
"""


if __name__ == '__main__':
    pass