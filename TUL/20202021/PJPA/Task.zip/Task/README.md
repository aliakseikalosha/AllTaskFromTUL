# PJPA LS 2020/2021
## Zdrojové kódy z přednášek a šablony pro cvičení 

### Do svého repozitáře si nakopírujte soubor .gitignore z tohoto repozitáře.

