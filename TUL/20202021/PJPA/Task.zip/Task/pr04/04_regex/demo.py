import re

MAIL = re.compile(r'[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}', re.IGNORECASE)
USER_NAME = re.compile(r',(\w+\.\w+),')

def main():
    with open("pjpa2021.csv", encoding="utf-8") as ifile:
        data = ifile.read()


    mails = MAIL.findall(data)
    print(type(mails))
    user_names = USER_NAME.finditer(data)
    print(type(user_names))

    for mail in mails:
        print(mail)

    for user_name in user_names:
        #print(user_name)
        print(user_name.groups()[0])

if __name__ == '__main__':
    main()