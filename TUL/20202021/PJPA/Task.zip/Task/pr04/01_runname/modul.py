"""
Kod mimo funkce se provede při spuštění i při importu,
pokud není uzavřen v podmínce main.
"""


def fce():
    return "hodnota konstanty AAA name : {}".format(__name__)

if __name__ == '__main__':
    print("MODUL", fce())