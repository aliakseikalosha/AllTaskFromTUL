"""
ukazka modul importu 
"""

import modul

if __name__ == '__main__':
    print("IMPORT - modul byl naimportován")
    print(type(modul))
    print(dir(modul))
    print(modul.__name__)
    print(modul.fce())
