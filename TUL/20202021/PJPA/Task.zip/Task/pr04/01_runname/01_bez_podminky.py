"""
Kod mimo funkce se provede při spuštění i při importu,
pokud není uzavřen v podmínce main.
"""


def fce():
    return "hodnota konstanty name : {}".format(__name__)

print("MODUL", fce())