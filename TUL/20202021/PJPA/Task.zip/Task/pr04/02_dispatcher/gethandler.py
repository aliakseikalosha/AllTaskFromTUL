# -*- coding: utf-8 -*-
"""
Mock WWW aplikace / obsahuje 4 endpointy
"""

def index():
    """
    index of site
    """
    return 'ahoj tady index'


def page1():
    """
    nejaka zajimava stranka
    """
    return 'lorem ipsum a tak dále'

def page2():
    """
    nejaka zajimava stranka
    """
    return 'stránka 2'

def page3():
    """
    nejaka zajimava stranka
    """
    return 'stránka 3'


def page4():
    """
    nejaka zajimava stranka
    """
    return 'stránka 4'