"""
Prace se souborem, textove i binarne
"""


def show_binary():
    """
    textovy soubor muzeme otevrit i jako binarni
    rozdil je v chovani na platforme Windows z duvodu jine sekvence pro konce radku
    v Unixu neni vlastne nutne, ale pro lepsi prenositelnost ho muzete nechat
    """
    with open("soudata.txt", "rb") as bin_file:
        print(bin_file.read())


def show_text():
    """
    textovy soubor a ukazka pohybu v suboru pomoci seek
    """

    with open("soudata.txt", "r", encoding="utf-8") as text_file:
        print("filename", text_file.name)
        print("object methods", dir(text_file))
        print("pozice kurzoru:", text_file.tell())
        print("nacti 16 bytes", text_file.read(16))
        print("pozice kurzoru pred posunem:", text_file.tell())
        text_file.seek(28)
        print("pozice kurzoru, posun na 28 b:", text_file.tell())
        print("nacti 10 bytes", text_file.read(10))
        print("soubor i pro zapis? ", text_file.writable())


def show_iter():
    """
    textovy soubor a ukazka iterace přes řádky
    """

    with open("soudata.txt", "r", encoding="utf-8") as text_file:
        for nr, line in enumerate(text_file):
            print(nr, line.strip())


def show_readlines():
    """
    textovy soubor a ukazka metody readlines
    parametr hint - read max. hint bytes
    """

    with open("soudata.txt", "r", encoding="utf-8") as text_file:
        data = text_file.readlines(32)

    for nr, line in enumerate(data):
        print(nr, line.strip())


def show_except():
    """
    ukázka výjimky
    """
    try:
        with open("nofile.txt", "r", encoding="utf-8") as text_file:
            for nr, line in enumerate(text_file):
                print(nr, line.strip()) 
    except FileNotFoundError as e:
        print(e)
        print("soubor neexistuje")
        exit()            

if __name__ == "__main__":

    #print("EXCEPTION")
    #show_except()


    #print("SEEK IN TEXT")
    #show_text()

    #print("ITERACE")
    #show_iter()

    #print("READ LINES")
    #show_readlines()

    print("BINARY")
    show_binary()
