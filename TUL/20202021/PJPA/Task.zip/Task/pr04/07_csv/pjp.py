import csv

with open('pjpa2021.csv', "r") as f:
    reader = csv.DictReader(f)
    header = reader.fieldnames
    good_data = []
    bad_data = []
    
    for row in reader:
        print(row['email'])