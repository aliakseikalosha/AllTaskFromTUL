package tul.alg2.lesson;

import java.io.IOException;
import java.util.Scanner;

public class Lesson20200225 {
    /*
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws IOException {
        new Lesson25022020().Solve2x2();
    }

    private void Solve2x2(){
        Matice2x2 A = new Matice2x2();
        A.fillData(sc);
        if(A.det()!=0){
            //double x = (b2c1-b1c2)/det(A);
            //double y=(a1c2-a2c1)/det(A);
            //System.out.println("reseni je x1:"+x+", x2:"+y+" ");
        }else{
            System.out.println("Nema reseni");
        }
    }
    //
    private class  Matice2x2{
        private float[][]  data = new float[2][2];
        public  float get(int x,int y){

        }
        public void fillData(Scanner sc){
            for (int i = 0; i < data.length; i++) {
                for (int j = 0; j < data[0].length; j++) {
                    data[i][j]=sc.nextFloat();
                }
            }
        }
        public float det(){
            return data[0][0]*data[1][1]-data[1][0]*data[0][1];
        }
    }
    */
}
