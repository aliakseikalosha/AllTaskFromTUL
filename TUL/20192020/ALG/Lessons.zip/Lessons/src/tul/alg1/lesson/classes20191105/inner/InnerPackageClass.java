package tul.alg1.lesson.classes20191105.inner;

public class InnerPackageClass {
    public void PrintText(){
        System.out.println("Hi from package tul.alg1.lesson.classes.inner");
    }
}
