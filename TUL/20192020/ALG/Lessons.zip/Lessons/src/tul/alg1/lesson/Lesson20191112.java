package tul.alg1.lesson;

import java.util.Scanner;

public class Lesson20191112 {

    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
//we have a test that day
    }
}
